# Jack Jakalas

Self-hosted trading signal and execution backend using Flask + MetaTrader.

## Setup Instructions

1. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```

2. Run Redis and PostgreSQL locally or in Docker.

3. Initialize DB:
   ```bash
   flask shell
   >>> from app import db
   >>> db.create_all()
   ```

4. Start the server:
   ```bash
   python run.py
   ```