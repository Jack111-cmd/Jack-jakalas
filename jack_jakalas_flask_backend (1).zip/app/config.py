class Config:
    SQLALCHEMY_DATABASE_URI = 'postgresql://user:pass@localhost/jackjakalas'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    REDIS_URL = "redis://localhost:6379/0"
    SECRET_KEY = 'super-secret-key'